
Dataset (TMDb Movie Dataset)
Prueba de Conocimientos

## Tabla de contenido
<ul>
<li><a href="#intro">Introduction</a></li>
<li><a href="#wrangling">Data Wrangling</a>
    <ul>
        <li><a href="#cleaning">Data Cleaning</a></li>
    </ul>
</li>
<li><a href="#eda">Exploratory Data Analysis</a></li>
<li><a href="#conclusions">Conclusions</a></li>
<li><a href="#limitations">Limitations</a></li>
</ul>


```python
# importando todas las bibliotecas / archivos necesarios
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import seaborn as sns

# Esto asegura que todas las visualizaciones de datos estén trazadas en el cuaderno y no en una ventana separada.
% matplotlib inline
```


```python
<a id='wrangling'></a>
## Data Wrangling

>los datos se cargarán y luego podremos explorar los datos y eliminar las columnas / filas que no son necesarias. Esto nos ayudará a analizar los datos con bastante facilidad.
### General Properties
```


```python
# Cargando los datos y almacenándolos en 'df'
df = pd.read_csv('tmdb-movies.csv')

# Echando un vistazo a las primeras 5 filas del conjunto de datos con las columnas proporcionadas intactas
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>id</th>
      <th>imdb_id</th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>original_title</th>
      <th>cast</th>
      <th>homepage</th>
      <th>director</th>
      <th>tagline</th>
      <th>...</th>
      <th>overview</th>
      <th>runtime</th>
      <th>genres</th>
      <th>production_companies</th>
      <th>release_date</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
      <th>budget_adj</th>
      <th>revenue_adj</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>135397</td>
      <td>tt0369610</td>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Jurassic World</td>
      <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
      <td>http://www.jurassicworld.com/</td>
      <td>Colin Trevorrow</td>
      <td>The park is open.</td>
      <td>...</td>
      <td>Twenty-two years after the events of Jurassic ...</td>
      <td>124</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Universal Studios|Amblin Entertainment|Legenda...</td>
      <td>6/9/15</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>1.379999e+08</td>
      <td>1.392446e+09</td>
    </tr>
    <tr>
      <th>1</th>
      <td>76341</td>
      <td>tt1392190</td>
      <td>28.419936</td>
      <td>150000000</td>
      <td>378436354</td>
      <td>Mad Max: Fury Road</td>
      <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
      <td>http://www.madmaxmovie.com/</td>
      <td>George Miller</td>
      <td>What a Lovely Day.</td>
      <td>...</td>
      <td>An apocalyptic story set in the furthest reach...</td>
      <td>120</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
      <td>5/13/15</td>
      <td>6185</td>
      <td>7.1</td>
      <td>2015</td>
      <td>1.379999e+08</td>
      <td>3.481613e+08</td>
    </tr>
    <tr>
      <th>2</th>
      <td>262500</td>
      <td>tt2908446</td>
      <td>13.112507</td>
      <td>110000000</td>
      <td>295238201</td>
      <td>Insurgent</td>
      <td>Shailene Woodley|Theo James|Kate Winslet|Ansel...</td>
      <td>http://www.thedivergentseries.movie/#insurgent</td>
      <td>Robert Schwentke</td>
      <td>One Choice Can Destroy You</td>
      <td>...</td>
      <td>Beatrice Prior must confront her inner demons ...</td>
      <td>119</td>
      <td>Adventure|Science Fiction|Thriller</td>
      <td>Summit Entertainment|Mandeville Films|Red Wago...</td>
      <td>3/18/15</td>
      <td>2480</td>
      <td>6.3</td>
      <td>2015</td>
      <td>1.012000e+08</td>
      <td>2.716190e+08</td>
    </tr>
    <tr>
      <th>3</th>
      <td>140607</td>
      <td>tt2488496</td>
      <td>11.173104</td>
      <td>200000000</td>
      <td>2068178225</td>
      <td>Star Wars: The Force Awakens</td>
      <td>Harrison Ford|Mark Hamill|Carrie Fisher|Adam D...</td>
      <td>http://www.starwars.com/films/star-wars-episod...</td>
      <td>J.J. Abrams</td>
      <td>Every generation has a story.</td>
      <td>...</td>
      <td>Thirty years after defeating the Galactic Empi...</td>
      <td>136</td>
      <td>Action|Adventure|Science Fiction|Fantasy</td>
      <td>Lucasfilm|Truenorth Productions|Bad Robot</td>
      <td>12/15/15</td>
      <td>5292</td>
      <td>7.5</td>
      <td>2015</td>
      <td>1.839999e+08</td>
      <td>1.902723e+09</td>
    </tr>
    <tr>
      <th>4</th>
      <td>168259</td>
      <td>tt2820852</td>
      <td>9.335014</td>
      <td>190000000</td>
      <td>1506249360</td>
      <td>Furious 7</td>
      <td>Vin Diesel|Paul Walker|Jason Statham|Michelle ...</td>
      <td>http://www.furious7.com/</td>
      <td>James Wan</td>
      <td>Vengeance Hits Home</td>
      <td>...</td>
      <td>Deckard Shaw seeks revenge against Dominic Tor...</td>
      <td>137</td>
      <td>Action|Crime|Thriller</td>
      <td>Universal Pictures|Original Film|Media Rights ...</td>
      <td>4/1/15</td>
      <td>2947</td>
      <td>7.3</td>
      <td>2015</td>
      <td>1.747999e+08</td>
      <td>1.385749e+09</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
# Inspeccionar los tipos de datos y buscar instancias de datos faltantes o posiblemente errantes
df.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 10866 entries, 0 to 10865
    Data columns (total 21 columns):
    id                      10866 non-null int64
    imdb_id                 10856 non-null object
    popularity              10866 non-null float64
    budget                  10866 non-null int64
    revenue                 10866 non-null int64
    original_title          10866 non-null object
    cast                    10790 non-null object
    homepage                2936 non-null object
    director                10822 non-null object
    tagline                 8042 non-null object
    keywords                9373 non-null object
    overview                10862 non-null object
    runtime                 10866 non-null int64
    genres                  10843 non-null object
    production_companies    9836 non-null object
    release_date            10866 non-null object
    vote_count              10866 non-null int64
    vote_average            10866 non-null float64
    release_year            10866 non-null int64
    budget_adj              10866 non-null float64
    revenue_adj             10866 non-null float64
    dtypes: float64(4), int64(6), object(11)
    memory usage: 1.7+ MB



```python
rows, col = df.query('budget == 0').shape
print('There are {} rows and {} columns'.format(rows, col))
```

    There are 5696 rows and 21 columns



```python
rows, col = df.query('revenue == 0').shape
print('There are {} rows and {} columns'.format(rows, col))
```

    There are 6016 rows and 21 columns



```python
rows, col = df.query('runtime == 0').shape
print('There are {} rows and {} columns'.format(rows, col))
```

    There are 31 rows and 21 columns


<a id='cleaning'></a>
### Limpieza de datos

>En primer lugar, eliminaremos las columnas que no son necesarias para nuestro análisis. Son `id`,` imdb_id`, `budget_adj`,` revenue_adj`, `homepage`,` tagline`, `keywords` y` overview`.
>
> En segundo lugar, todas las filas duplicadas presentes, si las hay, serán eliminadas.
>
> Luego, cambiaremos el tipo de datos de la columna `release_date` de cadena a fecha y hora.
>
> Actualmente, hay 5696 filas donde la columna `presupuesto` tiene un valor de 0, 6016 filas donde la columna` ingreso` tiene un valor de 0 y 31 filas donde la columna `tiempo de ejecución` tiene un valor de 0. Todos estos 0 Los valores se convertirán a NaN.

> <h3>1. Eliminar las columnas que no son necesarias</h3>


```python
# Lista de columnas que se van a eliminar / eliminar
col = ['id', 'imdb_id', 'budget_adj', 'revenue_adj', 'homepage',  'tagline', 'keywords', 'overview']

# Eliminando las columnas
df.drop(col, axis = 1, inplace = True)

#comprobando si las columnas han sido eliminadas
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>original_title</th>
      <th>cast</th>
      <th>director</th>
      <th>runtime</th>
      <th>genres</th>
      <th>production_companies</th>
      <th>release_date</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000</td>
      <td>1513528810</td>
      <td>Jurassic World</td>
      <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
      <td>Colin Trevorrow</td>
      <td>124</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Universal Studios|Amblin Entertainment|Legenda...</td>
      <td>6/9/15</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>1</th>
      <td>28.419936</td>
      <td>150000000</td>
      <td>378436354</td>
      <td>Mad Max: Fury Road</td>
      <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
      <td>George Miller</td>
      <td>120</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
      <td>5/13/15</td>
      <td>6185</td>
      <td>7.1</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>2</th>
      <td>13.112507</td>
      <td>110000000</td>
      <td>295238201</td>
      <td>Insurgent</td>
      <td>Shailene Woodley|Theo James|Kate Winslet|Ansel...</td>
      <td>Robert Schwentke</td>
      <td>119</td>
      <td>Adventure|Science Fiction|Thriller</td>
      <td>Summit Entertainment|Mandeville Films|Red Wago...</td>
      <td>3/18/15</td>
      <td>2480</td>
      <td>6.3</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.173104</td>
      <td>200000000</td>
      <td>2068178225</td>
      <td>Star Wars: The Force Awakens</td>
      <td>Harrison Ford|Mark Hamill|Carrie Fisher|Adam D...</td>
      <td>J.J. Abrams</td>
      <td>136</td>
      <td>Action|Adventure|Science Fiction|Fantasy</td>
      <td>Lucasfilm|Truenorth Productions|Bad Robot</td>
      <td>12/15/15</td>
      <td>5292</td>
      <td>7.5</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9.335014</td>
      <td>190000000</td>
      <td>1506249360</td>
      <td>Furious 7</td>
      <td>Vin Diesel|Paul Walker|Jason Statham|Michelle ...</td>
      <td>James Wan</td>
      <td>137</td>
      <td>Action|Crime|Thriller</td>
      <td>Universal Pictures|Original Film|Media Rights ...</td>
      <td>4/1/15</td>
      <td>2947</td>
      <td>7.3</td>
      <td>2015</td>
    </tr>
  </tbody>
</table>
</div>



> <h3>2. liminar filas duplicadas (si las hay)</h3>


```python
# eliminando filas duplicadas
# la primera entrada se mantiene por defecto
df.drop_duplicates(inplace=True)

rows, col = df.shape
print('There are now {} columns and {} entries of movie data'.format(col, rows-1))
```

    There are now 13 columns and 10864 entries of movie data


> <h3>3. Cambiar el tipo de datos de la columna `release_date`</h3>


```python
df['release_date'] = pd.to_datetime(df['release_date']) 
```


```python
# Compruebe si el cambio ha tenido lugar con éxito
df.dtypes
```




    popularity                     float64
    budget                           int64
    revenue                          int64
    original_title                  object
    cast                            object
    director                        object
    runtime                          int64
    genres                          object
    production_companies            object
    release_date            datetime64[ns]
    vote_count                       int64
    vote_average                   float64
    release_year                     int64
    dtype: object



> <h3>4. Manejo de 0 valores en las columnas `presupuesto`,` ingresos` y `tiempo de ejecución`</h3>


```python
# Hacer una lista de las 3 columnas.
temp_col = ['budget', 'revenue', 'runtime']

# Reemplazando todos los valores 0 con NaN
df[temp_col] = df[temp_col].replace(0, np.NAN)
```


```python
# Eliminar / Borrar todos los valores de NaN
# El subconjunto ayuda a definir en qué columnas buscar valores perdidos
df.dropna(subset = temp_col, inplace = True)
rows, col = df.shape

print('Now there are only {} entries'.format(rows-1))
```

    Now there are only 3853 entries


>Ese es el final de nuestro proceso de limpieza de datos. Echemos un vistazo al conjunto de datos ahora.


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>original_title</th>
      <th>cast</th>
      <th>director</th>
      <th>runtime</th>
      <th>genres</th>
      <th>production_companies</th>
      <th>release_date</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000.0</td>
      <td>1.513529e+09</td>
      <td>Jurassic World</td>
      <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
      <td>Colin Trevorrow</td>
      <td>124.0</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Universal Studios|Amblin Entertainment|Legenda...</td>
      <td>2015-06-09</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>1</th>
      <td>28.419936</td>
      <td>150000000.0</td>
      <td>3.784364e+08</td>
      <td>Mad Max: Fury Road</td>
      <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
      <td>George Miller</td>
      <td>120.0</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
      <td>2015-05-13</td>
      <td>6185</td>
      <td>7.1</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>2</th>
      <td>13.112507</td>
      <td>110000000.0</td>
      <td>2.952382e+08</td>
      <td>Insurgent</td>
      <td>Shailene Woodley|Theo James|Kate Winslet|Ansel...</td>
      <td>Robert Schwentke</td>
      <td>119.0</td>
      <td>Adventure|Science Fiction|Thriller</td>
      <td>Summit Entertainment|Mandeville Films|Red Wago...</td>
      <td>2015-03-18</td>
      <td>2480</td>
      <td>6.3</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>3</th>
      <td>11.173104</td>
      <td>200000000.0</td>
      <td>2.068178e+09</td>
      <td>Star Wars: The Force Awakens</td>
      <td>Harrison Ford|Mark Hamill|Carrie Fisher|Adam D...</td>
      <td>J.J. Abrams</td>
      <td>136.0</td>
      <td>Action|Adventure|Science Fiction|Fantasy</td>
      <td>Lucasfilm|Truenorth Productions|Bad Robot</td>
      <td>2015-12-15</td>
      <td>5292</td>
      <td>7.5</td>
      <td>2015</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9.335014</td>
      <td>190000000.0</td>
      <td>1.506249e+09</td>
      <td>Furious 7</td>
      <td>Vin Diesel|Paul Walker|Jason Statham|Michelle ...</td>
      <td>James Wan</td>
      <td>137.0</td>
      <td>Action|Crime|Thriller</td>
      <td>Universal Pictures|Original Film|Media Rights ...</td>
      <td>2015-04-01</td>
      <td>2947</td>
      <td>7.3</td>
      <td>2015</td>
    </tr>
  </tbody>
</table>
</div>



<a id='eda'></a>
## Análisis exploratorio de datos
<br>¡Ahora que todos los datos se han limpiado a nuestro gusto, podemos seguir adelante, analizar el conjunto de datos y hacer algunos descubrimientos!

> ### I.) 1. ¿Cuáles son las popularidades promedio de las películas según los niveles del presupuesto?


```python
# Primero tenemos que hacer columnas para rangos de presupuesto
# Utilizamos los métodos de corte de la biblioteca de pandas para hacerlo.
df['budget_ranges'] = pd.cut(df['budget'], df['budget'].describe()[3:8], labels = ['Low', 'Medium', 'Moderately High', 'High'])
```


```python
# Echando un vistazo a nuestro conjunto de datos después de agregar una nueva columna
df.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>original_title</th>
      <th>cast</th>
      <th>director</th>
      <th>runtime</th>
      <th>genres</th>
      <th>production_companies</th>
      <th>release_date</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
      <th>budget_ranges</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000.0</td>
      <td>1.513529e+09</td>
      <td>Jurassic World</td>
      <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
      <td>Colin Trevorrow</td>
      <td>124.0</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Universal Studios|Amblin Entertainment|Legenda...</td>
      <td>2015-06-09</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>High</td>
    </tr>
    <tr>
      <th>1</th>
      <td>28.419936</td>
      <td>150000000.0</td>
      <td>3.784364e+08</td>
      <td>Mad Max: Fury Road</td>
      <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
      <td>George Miller</td>
      <td>120.0</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
      <td>2015-05-13</td>
      <td>6185</td>
      <td>7.1</td>
      <td>2015</td>
      <td>High</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Ahora nos enteramos de las popularidades promedio de cada nivel.
df.groupby('budget_ranges')['popularity'].mean()
```




    budget_ranges
    Low                0.686413
    Medium             0.951718
    Moderately High    1.142414
    High               2.080911
    Name: popularity, dtype: float64




```python
# Trazando la información anterior en un gráfico de barras
sns.set()
df.groupby('budget_ranges')['popularity'].mean().plot(kind = 'bar', figsize = (16, 8))

# Configuración del título de la trama.
plt.title('Average popularities of movies by budget levels', fontsize = 18)

# Configurando las etiquetas de los ejes xy y
plt.xlabel('Budget Ranges', fontsize = 16)
plt.ylabel('Popularity', fontsize = 16);
```


![png](output_25_0.png)


Se puede observar que las películas con un rango de presupuesto más alto tienden a ser más populares entre la audiencia.

> ### I.) 2. ¿Cuáles son las tendencias de ganancias de un año a otro?


```python
# Primero necesitamos insertar una columna para el valor de ganancia / pérdida de cada película
df.insert(3, 'profit_loss', df['revenue'] - df['budget'])
```


```python
# Comprobar para ver si la columna fue insertada
df.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>profit_loss</th>
      <th>original_title</th>
      <th>cast</th>
      <th>director</th>
      <th>runtime</th>
      <th>genres</th>
      <th>production_companies</th>
      <th>release_date</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
      <th>budget_ranges</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>32.985763</td>
      <td>150000000.0</td>
      <td>1.513529e+09</td>
      <td>1.363529e+09</td>
      <td>Jurassic World</td>
      <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
      <td>Colin Trevorrow</td>
      <td>124.0</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Universal Studios|Amblin Entertainment|Legenda...</td>
      <td>2015-06-09</td>
      <td>5562</td>
      <td>6.5</td>
      <td>2015</td>
      <td>High</td>
    </tr>
    <tr>
      <th>1</th>
      <td>28.419936</td>
      <td>150000000.0</td>
      <td>3.784364e+08</td>
      <td>2.284364e+08</td>
      <td>Mad Max: Fury Road</td>
      <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
      <td>George Miller</td>
      <td>120.0</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
      <td>2015-05-13</td>
      <td>6185</td>
      <td>7.1</td>
      <td>2015</td>
      <td>High</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.groupby('release_year')['profit_loss'].sum().plot(kind = 'line', figsize = (16, 8), color = 'g')
plt.title('Profit Trends from year to year', fontsize = 18)
plt.xlabel('Year', fontsize = 16)
plt.ylabel('Profit', fontsize = 16);
```


![png](output_30_0.png)


Las ganancias han aumentado exponencialmente con cada año que pasa, especialmente después del comienzo del siglo XXI.

> ### I.) 3. ¿Cuáles son los tiempos de ejecución promedio de las películas a lo largo de los años?


```python
df.groupby('release_year')['runtime'].mean().plot(kind='line', figsize = (16, 8), color = 'r')
plt.title('Average Runtime of Movies over the Years', fontsize = 18)
plt.xlabel('Year', fontsize = 16)
plt.ylabel('Runtime', fontsize = 16);
```


![png](output_33_0.png)


El tiempo de ejecución de las películas ha disminuido con cada año que pasa. Experimentó una subida durante los años 60, pero luego ha disminuido constantemente a lo largo de los años. El más bajo fue de alrededor de 100-110 minutos. Actualmente, las películas tienden a durar alrededor de los 110 minutos.

>### I.) 4. ¿Cuáles son las 5 películas rentables más baratas y caras de todos los tiempos?

<br><i>Para esto estableceremos un valor estándar de ganancia que se debe cumplir, ese valor será de $ 50,000,000</i>


```python
# creando una lista de columnas que serán vistas
col = ['original_title', 'cast', 'director', 'budget', 'revenue', 'profit_loss']

# Uso de la función de consulta para mostrar registros de películas que tienen un beneficio de más de $ 50,000,000
# También utiliza la función sort_values para asegurarse de que esté ordenada de acuerdo con la columna de presupuesto

df.query('profit_loss>50000000')[col].sort_values('budget', ascending = False).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>original_title</th>
      <th>cast</th>
      <th>director</th>
      <th>budget</th>
      <th>revenue</th>
      <th>profit_loss</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>3375</th>
      <td>Pirates of the Caribbean: On Stranger Tides</td>
      <td>Johnny Depp|PenÃ©lope Cruz|Geoffrey Rush|Ian M...</td>
      <td>Rob Marshall</td>
      <td>380000000.0</td>
      <td>1.021683e+09</td>
      <td>6.416830e+08</td>
    </tr>
    <tr>
      <th>7387</th>
      <td>Pirates of the Caribbean: At World's End</td>
      <td>Johnny Depp|Orlando Bloom|Keira Knightley|Geof...</td>
      <td>Gore Verbinski</td>
      <td>300000000.0</td>
      <td>9.610000e+08</td>
      <td>6.610000e+08</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Avengers: Age of Ultron</td>
      <td>Robert Downey Jr.|Chris Hemsworth|Mark Ruffalo...</td>
      <td>Joss Whedon</td>
      <td>280000000.0</td>
      <td>1.405036e+09</td>
      <td>1.125036e+09</td>
    </tr>
    <tr>
      <th>6570</th>
      <td>Superman Returns</td>
      <td>Brandon Routh|Kevin Spacey|Kate Bosworth|James...</td>
      <td>Bryan Singer</td>
      <td>270000000.0</td>
      <td>3.910812e+08</td>
      <td>1.210812e+08</td>
    </tr>
    <tr>
      <th>1929</th>
      <td>Tangled</td>
      <td>Zachary Levi|Mandy Moore|Donna Murphy|Ron Perl...</td>
      <td>Nathan Greno|Byron Howard</td>
      <td>260000000.0</td>
      <td>5.917949e+08</td>
      <td>3.317949e+08</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.query('profit_loss>50000000')[col].sort_values('budget', ascending = True).head(5)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>original_title</th>
      <th>cast</th>
      <th>director</th>
      <th>budget</th>
      <th>revenue</th>
      <th>profit_loss</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>10495</th>
      <td>The Karate Kid, Part II</td>
      <td>Ralph Macchio|Pat Morita|Martin Kove|Charlie T...</td>
      <td>John G. Avildsen</td>
      <td>113.0</td>
      <td>115103979.0</td>
      <td>115103866.0</td>
    </tr>
    <tr>
      <th>7447</th>
      <td>Paranormal Activity</td>
      <td>Katie Featherston|Micah Sloat|Mark Fredrichs|A...</td>
      <td>Oren Peli</td>
      <td>15000.0</td>
      <td>193355800.0</td>
      <td>193340800.0</td>
    </tr>
    <tr>
      <th>2449</th>
      <td>The Blair Witch Project</td>
      <td>Heather Donahue|Michael C. Williams|Joshua Leo...</td>
      <td>Daniel Myrick|Eduardo SÃ¡nchez</td>
      <td>25000.0</td>
      <td>248000000.0</td>
      <td>247975000.0</td>
    </tr>
    <tr>
      <th>7057</th>
      <td>Open Water</td>
      <td>Blanchard Ryan|Daniel Travis|Saul Stein|Michae...</td>
      <td>Chris Kentis</td>
      <td>130000.0</td>
      <td>54667954.0</td>
      <td>54537954.0</td>
    </tr>
    <tr>
      <th>10759</th>
      <td>Halloween</td>
      <td>Donald Pleasence|Jamie Lee Curtis|P.J. Soles|N...</td>
      <td>John Carpenter</td>
      <td>300000.0</td>
      <td>70000000.0</td>
      <td>69700000.0</td>
    </tr>
  </tbody>
</table>
</div>



> ### I.) 5. ¿Qué variables afectan los ingresos y la popularidad de una película?


```python
# Use corr para calcular la correlación de columnas
df.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>popularity</th>
      <th>budget</th>
      <th>revenue</th>
      <th>profit_loss</th>
      <th>runtime</th>
      <th>vote_count</th>
      <th>vote_average</th>
      <th>release_year</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>popularity</th>
      <td>1.000000</td>
      <td>0.446987</td>
      <td>0.615535</td>
      <td>0.596201</td>
      <td>0.215092</td>
      <td>0.780096</td>
      <td>0.317866</td>
      <td>0.173278</td>
    </tr>
    <tr>
      <th>budget</th>
      <td>0.446987</td>
      <td>1.000000</td>
      <td>0.688556</td>
      <td>0.526818</td>
      <td>0.260977</td>
      <td>0.556937</td>
      <td>0.024169</td>
      <td>0.268040</td>
    </tr>
    <tr>
      <th>revenue</th>
      <td>0.615535</td>
      <td>0.688556</td>
      <td>1.000000</td>
      <td>0.979133</td>
      <td>0.250298</td>
      <td>0.754567</td>
      <td>0.227123</td>
      <td>0.139140</td>
    </tr>
    <tr>
      <th>profit_loss</th>
      <td>0.596201</td>
      <td>0.526818</td>
      <td>0.979133</td>
      <td>1.000000</td>
      <td>0.220238</td>
      <td>0.728348</td>
      <td>0.259435</td>
      <td>0.087971</td>
    </tr>
    <tr>
      <th>runtime</th>
      <td>0.215092</td>
      <td>0.260977</td>
      <td>0.250298</td>
      <td>0.220238</td>
      <td>1.000000</td>
      <td>0.273771</td>
      <td>0.351712</td>
      <td>-0.112453</td>
    </tr>
    <tr>
      <th>vote_count</th>
      <td>0.780096</td>
      <td>0.556937</td>
      <td>0.754567</td>
      <td>0.728348</td>
      <td>0.273771</td>
      <td>1.000000</td>
      <td>0.387210</td>
      <td>0.207191</td>
    </tr>
    <tr>
      <th>vote_average</th>
      <td>0.317866</td>
      <td>0.024169</td>
      <td>0.227123</td>
      <td>0.259435</td>
      <td>0.351712</td>
      <td>0.387210</td>
      <td>1.000000</td>
      <td>-0.134246</td>
    </tr>
    <tr>
      <th>release_year</th>
      <td>0.173278</td>
      <td>0.268040</td>
      <td>0.139140</td>
      <td>0.087971</td>
      <td>-0.112453</td>
      <td>0.207191</td>
      <td>-0.134246</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>



<b>En caso de ingresos.</b>
<ul>
    <li>Fuerte correlación con la popularidad, el presupuesto y el conteo de votos.</li>
    <li>Correlación débil con el tiempo de ejecución.</li>
</ul>

<b>En caso de popularidad,</b>
<ul>
    <li>Correlación moderada con presupuesto.</li>
    <li>Fuerte correlación con los ingresos, ganancias y pérdidas y conteo de votos.</li>
</ul><br>

<h3>Ahora veremos uno de cada nivel de correlación.</h3><br>
<i><font size = 4>Correlación Fuerte: Presupuesto vs Ingresos</font></i>


```python
# Trazar diagramas de dispersión para ver la correlación visualmente
sns.regplot(x = df['budget'], y = df['revenue'], fit_reg = False)
# Obtención del tamaño de la muestra.
fig_size = plt.rcParams["figure.figsize"]

# Cambiando el largo y ancho del grafico.
fig_size[0] = 16
fig_size[1] = 8
plt.rcParams["figure.figsize"] = fig_size

plt.title('Budget vs Revenue', fontsize = 18)
plt.xlabel('Budget', fontsize = 16)
plt.ylabel('Revenue', fontsize = 16);
```


![png](output_41_0.png)


<i><font size = 4>Correlación Moderada: Presupuesto vs Popularidad</font></i>


```python
sns.regplot(x = df['budget'], y = df['popularity'], fit_reg = False)

fig_size = plt.rcParams["figure.figsize"]
fig_size[0] = 16
fig_size[1] = 8

plt.rcParams["figure.figsize"] = fig_size
plt.title('Budget vs Popularity', fontsize = 18)
plt.xlabel('Budget', fontsize = 16)
plt.ylabel('Popularity', fontsize = 16);
```


![png](output_43_0.png)


<i><font size = 4>Correlación débil: Runtime vs Ingresos</font></i>


```python
sns.regplot(x = df['runtime'], y = df['revenue'], fit_reg = False)

fig_size = plt.rcParams["figure.figsize"]
fig_size[0] = 16
fig_size[1] = 8

plt.rcParams["figure.figsize"] = fig_size
plt.title('Runtime vs Revenue', fontsize = 18)
plt.xlabel('Runtime', fontsize = 16)
plt.ylabel('Revenue', fontsize = 16);
```


![png](output_45_0.png)


> ### II.) 1. Genero


```python
# Primero, crearemos un marco de datos que contiene datos de todas las películas que han obtenido al menos $ 50 millones en ganancias
# Crea una lista de columnas que son requeridas
profit_col = ['original_title', 'cast', 'director', 'production_companies', 'genres', 'budget', 'revenue', 'runtime']
profit_df = df.query('profit_loss>50000000')[profit_col]

# Ver el marco de datos recién creado
profit_df.head(2)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>original_title</th>
      <th>cast</th>
      <th>director</th>
      <th>production_companies</th>
      <th>genres</th>
      <th>budget</th>
      <th>revenue</th>
      <th>runtime</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Jurassic World</td>
      <td>Chris Pratt|Bryce Dallas Howard|Irrfan Khan|Vi...</td>
      <td>Colin Trevorrow</td>
      <td>Universal Studios|Amblin Entertainment|Legenda...</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>150000000.0</td>
      <td>1.513529e+09</td>
      <td>124.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Mad Max: Fury Road</td>
      <td>Tom Hardy|Charlize Theron|Hugh Keays-Byrne|Nic...</td>
      <td>George Miller</td>
      <td>Village Roadshow Pictures|Kennedy Miller Produ...</td>
      <td>Action|Adventure|Science Fiction|Thriller</td>
      <td>150000000.0</td>
      <td>3.784364e+08</td>
      <td>120.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
#funcion que tomará cualquier columna como argumento de y mantendrá su pista
def calculate_count(column):
    # Convierta la columna en cadena y sepárela por '|'
    data = profit_df[column].str.cat(sep = '|')
    
   # Almacenando los valores por separado en una serie de Pandas
    data = pd.Series(data.split('|'))
    count = data.value_counts(ascending = False)
    
    return count
```


```python
#variable to store the retured value#variabl 
count = calculate_count('genres')

#printing top 5 values
count.head()
```




    Comedy       492
    Drama        481
    Action       464
    Thriller     405
    Adventure    379
    dtype: int64




```python
count.plot(kind='pie', figsize = (14, 14));
```


![png](output_50_0.png)


> ### II.) 2. Actor/Actrices


```python
#variable para almacenar el valor devuelto
count = calculate_count('cast')

# imprimiendo los 5 mejores valores
count.head()
```




    Tom Cruise            27
    Brad Pitt             25
    Tom Hanks             22
    Sylvester Stallone    21
    Cameron Diaz          20
    dtype: int64



> ### II.) 3. Director


```python
#variable para almacenar el valor devuelto
count = calculate_count('director')

# imprimiendo los 5 mejores valores
count.head()
```




    Steven Spielberg    23
    Robert Zemeckis     13
    Clint Eastwood      12
    Tim Burton          11
    Tony Scott          10
    dtype: int64



> ### II.) 4. Empresas de produccion 


```python
#variable para almacenar el valor devuelto
count = calculate_count('production_companies')

# imprimiendo los 5 mejores valores
count.head()
```




    Universal Pictures                        156
    Warner Bros.                              144
    Paramount Pictures                        130
    Twentieth Century Fox Film Corporation    118
    Columbia Pictures                          93
    dtype: int64



> ### II.) 5. Presupuesto


```python
# Recuperando el presupuesto promedio
profit_avg_budget = profit_df['budget'].mean()
print('The average budget of a succesful movie is ${0:.2f}'.format(profit_avg_budget))
```

    The average budget of a succesful movie is $60444957.76


> ### II.) 6. Tiempo de ejecución


```python
# Recuperando el tiempo de ejecución promedio
profit_avg_runtime = profit_df['runtime'].mean()
print('The average runtime of a succesful movie is {0:.1f}'.format(profit_avg_runtime))
```

    The average runtime of a succesful movie is 113.7


> ### Ingresos que pueden ser explicados


```python
# Recuperando el ingreso promedio
profit_avg_runtime = profit_df['revenue'].mean()
print('The average revenue of a succesful movie is {0:.1f}'.format(profit_avg_runtime))
```

    The average revenue of a succesful movie is 254957662.6

